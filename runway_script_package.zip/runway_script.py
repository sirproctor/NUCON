import requests
import time
import os

RUNWAY_API_KEY = "your_runway_api_key_here"
OUTPUT_DIR = os.path.expanduser("media_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

prompt = input("What should we generate? ")

headers = {
    "Authorization": f"Bearer {RUNWAY_API_KEY}",
    "Content-Type": "application/json"
}

data = {
    "prompt": prompt,
    "num_inference_steps": 25,
    "guidance_scale": 7.5,
    "width": 1024,
    "height": 576
}

print("\nSending to RunwayML...")
response = requests.post(
    "https://api.runwayml.com/v1/gen3alpha/generate",
    headers=headers,
    json=data
)

if response.status_code == 200:
    image_url = response.json().get("image_url")
    if image_url:
        img_data = requests.get(image_url)
        filename = f"image_{int(time.time())}.jpg"
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(img_data.content)
        print("✅ Image saved to:", filepath)
    else:
        print("⚠️ No image URL returned.")
else:
    print("❌ RunwayML Error:", response.status_code, response.text)
